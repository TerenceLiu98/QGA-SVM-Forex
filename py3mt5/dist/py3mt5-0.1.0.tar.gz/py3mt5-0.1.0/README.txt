py3mt5 

A enhanced py package with MetaTrader5. 

Feature:

1. Log In to your MT5 account
2. Initialize your Terminal 
3. Collect Data with Symbol and date 
4. Using Pandas to do some basic operation 
5. Shutdown Terminal  

